
  export const nftmarketaddress = "0xcF98fB6Be377c3066Dd09b9a7570d2eB3D3883C0"
  export const nftaddress = "0x7f5045DaC251D8636b21Aaf02B2DB20E69b38B25"
  